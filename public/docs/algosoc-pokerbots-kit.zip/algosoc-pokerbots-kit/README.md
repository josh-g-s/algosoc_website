# AlgoSoc Pokerbots — Starter Kit

```
bot.py                 your bot (edit this, upload this)
local_sim.py           play your bot against others locally
examples/              house bots to test against
engine/                the exact engine the tournament runs
```

## Quick start

```bash
python local_sim.py                                   # bot.py vs house bots, 50 tables
python local_sim.py --tables 200 --timeout 10         # more tables, set the clock
python local_sim.py bot.py examples/tight_aggressive.py
```

No dependencies beyond Python 3.9+.

## The game

- Texas Hold'em, eight-bot sit-and-go. No-Limit by default; the organisers may
  switch to Pot-Limit or Fixed-Limit, or cap raises per street. The rulebook
  PDF lists the settings in force (page 2), and every `state` tells you (`betting`, `raise_cap`).
- 2,000 chips each. Blinds 10/20, rising every 25 hands
  (10/20, 20/40, 30/60, 50/100, 75/150, 100/200, 150/300, 200/400, then doubling).
- Ends when one bot has every chip, or after 200 hands. Survivors at the cap
  split the remaining places' points by ICM (`engine/icm.py`).
- Points by place (default): 100, 60, 40, 25, 15, 10, 5, 0.
- Your tournament score is your average points per table.
  Day 1 = 1×G1 + 2×G2 + 3×G3 over three group rounds (later rounds count more).
  Day 2 is knockouts, scored per stage; see the rulebook, sections 5.7 to 5.13.

## Betting rules (summary)

- Raises are "raise to" amounts. Minimum raise = the last bet/raise this street
  (never less than the big blind). Maximum: your stack (No-Limit), the pot after
  calling (Pot-Limit), or exactly one bet (Fixed-Limit: 1 BB pre-flop/flop, 2 BB turn/river).
- If a raise cap is set, after that many bets/raises on a street you can only call or fold.
- You can always go all in. A short all-in doesn't reopen raising for bots that already acted.
- Side pots, uncalled bets returned, odd chip to the first winner left of the button.

Practise under other structures:

```bash
python local_sim.py --betting pot_limit
python local_sim.py --betting fixed_limit
python local_sim.py --raise-cap 3
```

## Your bot

Implement `Agent.act(state)` and return one of:

```python
{"action": "fold"}
{"action": "check"}
{"action": "call"}
{"action": "raise", "amount": 200}   # raise TO 200 on this street
{"action": "all_in"}
```

The full `state` reference is in the rulebook PDF, Part II, sections 12 to 15. The highlights:
`hole_cards`, `board`, `street`, `stacks`, `bets`, `pot`, `to_call`,
`min_raise_to`, `max_raise_to`, `legal_actions`, `history`.

A fresh `Agent()` is created for every table. Errors, timeouts and illegal
actions become a check when possible, otherwise a fold. `print()` is safe.
