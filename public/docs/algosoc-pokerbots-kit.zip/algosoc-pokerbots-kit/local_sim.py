"""Run your bot against the example bots on your own machine.

    python local_sim.py                      # bot.py vs house bots, 50 tables
    python local_sim.py --tables 200 --timeout 10
    python local_sim.py bot.py examples/tight_aggressive.py --tables 20

Every bot runs in its own process with the same time limit the platform
uses, so what you see here is what you'll get in the tournament.
"""
import argparse
import os
import random
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from engine import SitAndGo  # noqa: E402
from engine.players import SubprocessPlayer  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
HOUSE = ["examples/tight_aggressive.py", "examples/calling_station.py", "examples/random_bot.py"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("bots", nargs="*", default=["bot.py"])
    ap.add_argument("--tables", type=int, default=50)
    ap.add_argument("--timeout", type=float, default=10.0, help="ms per decision")
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--betting", choices=["no_limit", "pot_limit", "fixed_limit"], default="no_limit")
    ap.add_argument("--raise-cap", type=int, default=0, help="max bets/raises per street, 0 = none")
    args = ap.parse_args()

    bots = [os.path.join(HERE, b) if not os.path.isabs(b) else b for b in args.bots]
    rng = random.Random(args.seed)
    totals = {b: [0.0, 0, 0, 0, 0] for b in bots}  # points, tables, wins, timeouts, errors
    t0 = time.time()
    for t in range(args.tables):
        seats = list(bots)
        while len(seats) < 8:
            seats.append(os.path.join(HERE, rng.choice(HOUSE)))
        rng.shuffle(seats)
        players = [SubprocessPlayer(p, timeout_ms=args.timeout) for p in seats]
        try:
            res = SitAndGo(players, {"betting": args.betting, "raise_cap": args.raise_cap},
                           seed=rng.random()).play()
        finally:
            for p in players:
                p.close()
        seen = set()
        for i, path in enumerate(seats):
            if path in totals and path not in seen:
                seen.add(path)
                tot = totals[path]
                tot[0] += res["points"][i]
                tot[1] += 1
                tot[2] += res["places"][i] == 1
                tot[3] += players[i].stats.timeouts
                tot[4] += players[i].stats.errors
                if players[i].stats.error_samples and t == 0:
                    print("\n--- error from %s ---\n%s" % (os.path.basename(path), players[i].stats.error_samples[0]))
        print("\rtable %d/%d" % (t + 1, args.tables), end="", flush=True)
    print("\n\n%-28s %10s %6s %9s %7s" % ("bot", "avg pts", "wins", "timeouts", "errors"))
    for b, (pts, n, w, to, er) in totals.items():
        print("%-28s %10.2f %6d %9d %7d" % (os.path.relpath(b, HERE), pts / max(n, 1), w, to, er))
    print("\n%.1fs elapsed" % (time.time() - t0))


if __name__ == "__main__":
    main()
