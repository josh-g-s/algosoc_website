"""Your AlgoSoc Pokerbot.

Rename nothing: the platform imports `Agent` from this file. A fresh Agent()
is created for every table, so anything you store on `self` lasts for one
sit-and-go (up to 200 hands) and is then thrown away.

act(state) must return within the per-decision time limit. If it raises,
times out, or returns something illegal, you check when you can and fold
otherwise.
"""
import random


class Agent:
    def __init__(self):
        self.rng = random.Random()

    def on_table_start(self, info):
        """Optional. info: seat, num_players, starting_stack, blinds, points, ..."""
        self.seat = info["seat"]

    def act(self, state):
        """Return {"action": "fold" | "check" | "call" | "raise", "amount": int}.

        For "raise", amount is the total you want your bet to be this street
        ("raise to"), between state["min_raise_to"] and state["max_raise_to"].
        """
        legal = state["legal_actions"]
        hole = state["hole_cards"]          # e.g. ["As", "Kd"]
        ranks = sorted("23456789TJQKA".index(c[0]) for c in hole)
        strong = ranks[0] == ranks[1] or ranks[1] >= 11  # pair or J+ high

        if strong and "raise" in legal:
            target = state["min_raise_to"] + state["pot"] // 2
            return {"action": "raise", "amount": min(target, state["max_raise_to"])}
        if "check" in legal:
            return {"action": "check"}
        if state["to_call"] <= state["big_blind"] * 2 or strong:
            return {"action": "call"}
        return {"action": "fold"}

    def on_hand_end(self, summary):
        """Optional. summary: board, shown cards, winners, stacks, full history."""
        pass
