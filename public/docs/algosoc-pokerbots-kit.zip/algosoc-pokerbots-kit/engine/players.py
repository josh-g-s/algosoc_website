"""Seat adapters between the engine and bots.

SubprocessPlayer runs a bot file in its own Python process with a strict
per-decision time limit (this is what the tournament uses).
LocalPlayer runs an Agent class in-process with no time limit (handy for
house bots and quick local testing).
"""
import json
import os
import select
import subprocess
import sys
import time
import traceback

RUNNER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bot_runner.py")


class _Stats:
    def __init__(self):
        self.decisions = 0
        self.timeouts = 0
        self.errors = 0
        self.error_samples = []
        self.max_ms = 0.0
        self.total_ms = 0.0

    def note_error(self, text, strip=None):
        if strip:
            text = text.replace(strip, "")
        self.errors += 1
        if len(self.error_samples) < 3:
            self.error_samples.append(text[-2000:])

    def as_dict(self):
        return {
            "decisions": self.decisions,
            "timeouts": self.timeouts,
            "errors": self.errors,
            "error_samples": self.error_samples,
            "max_ms": round(self.max_ms, 3),
            "avg_ms": round(self.total_ms / self.decisions, 3) if self.decisions else 0.0,
        }


def _limit_resources():
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CPU, (300, 300))
    except Exception:
        pass


class SubprocessPlayer:
    def __init__(self, bot_path, timeout_ms=10.0, setup_timeout=5.0, stderr_path=None):
        self.bot_path = os.path.abspath(bot_path)
        self._strip = os.path.dirname(self.bot_path) + os.sep
        self.timeout = timeout_ms / 1000.0
        self.setup_timeout = setup_timeout
        self.stderr_path = stderr_path
        self.stats = _Stats()
        self.proc = None
        self.buf = b""
        self.dead = False
        self.next_id = 0

    # ----------------------------------------------------------- plumbing
    def _spawn(self):
        stderr = open(self.stderr_path, "ab") if self.stderr_path else subprocess.DEVNULL
        env = {"PATH": os.environ.get("PATH", ""), "PYTHONDONTWRITEBYTECODE": "1",
               "PYTHONUNBUFFERED": "1", "OMP_NUM_THREADS": "1"}
        self.proc = subprocess.Popen(
            [sys.executable, "-I", RUNNER, self.bot_path],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr,
            cwd=os.path.dirname(self.bot_path), env=env,
            preexec_fn=_limit_resources if os.name == "posix" else None,
        )
        if stderr is not subprocess.DEVNULL:
            stderr.close()
        self.fd = self.proc.stdout.fileno()
        os.set_blocking(self.fd, False)

    def _send(self, obj):
        if self.dead:
            return False
        try:
            self.proc.stdin.write((json.dumps(obj) + "\n").encode())
            self.proc.stdin.flush()
            return True
        except (BrokenPipeError, OSError, ValueError):
            self.dead = True
            return False

    def _readline(self, deadline):
        while b"\n" not in self.buf:
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                return None
            ready, _, _ = select.select([self.fd], [], [], remaining)
            if not ready:
                return None
            try:
                chunk = os.read(self.fd, 1 << 16)
            except BlockingIOError:
                continue
            if not chunk:
                self.dead = True
                return None
            self.buf += chunk
        line, self.buf = self.buf.split(b"\n", 1)
        return line

    def _wait_for(self, want_id, deadline):
        """Return the reply with id `want_id`, skipping stale late replies."""
        while True:
            line = self._readline(deadline)
            if line is None:
                return None
            try:
                msg = json.loads(line)
            except ValueError:
                continue
            if msg.get("type") == "load_error":
                return msg
            if msg.get("id") == want_id or (want_id is None and msg.get("type") == "loaded"):
                return msg

    # ------------------------------------------------------- engine hooks
    def start_table(self, seat, info):
        self.load_error = None
        if self.proc is None:
            self._spawn()
            msg = self._wait_for(None, time.perf_counter() + self.setup_timeout)
            if msg is None or msg.get("type") != "loaded":
                self.dead = True
                text = (msg or {}).get("error") or "Bot did not load within %.0fs" % self.setup_timeout
                self.load_error = text
                self.stats.note_error(text, self._strip)
                return
        self.next_id += 1
        if not self._send({"id": self.next_id, "type": "new_table", "info": info}):
            return
        msg = self._wait_for(self.next_id, time.perf_counter() + self.setup_timeout)
        if msg is None or msg.get("type") != "ready":
            self.dead = True
            text = (msg or {}).get("error") or "Agent() did not start within %.0fs" % self.setup_timeout
            self.load_error = text
            self.stats.note_error(text, self._strip)

    def act(self, state):
        self.stats.decisions += 1
        if self.dead:
            return None
        self.next_id += 1
        t0 = time.perf_counter()
        if not self._send({"id": self.next_id, "type": "act", "state": state}):
            return None
        msg = self._wait_for(self.next_id, t0 + self.timeout)
        ms = (time.perf_counter() - t0) * 1000
        self.stats.total_ms += ms
        self.stats.max_ms = max(self.stats.max_ms, ms)
        if msg is None:
            if self.dead:
                self.stats.note_error("Bot process exited unexpectedly.")
            else:
                self.stats.timeouts += 1
            return None
        if msg.get("type") == "error":
            self.stats.note_error(msg.get("error", "unknown error"), self._strip)
            return None
        return msg

    def hand_end(self, summary):
        self._send({"type": "hand_end", "summary": summary})

    def close(self):
        if self.proc is None:
            return
        try:
            self._send({"type": "quit"})
            self.proc.stdin.close()
        except Exception:
            pass
        try:
            self.proc.wait(timeout=0.5)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait()


class LocalPlayer:
    def __init__(self, agent_cls):
        self.agent_cls = agent_cls
        self.agent = None
        self.stats = _Stats()

    def start_table(self, seat, info):
        self.agent = self.agent_cls()
        if hasattr(self.agent, "on_table_start"):
            self.agent.on_table_start(info)

    def act(self, state):
        from .bot_runner import normalise
        self.stats.decisions += 1
        t0 = time.perf_counter()
        try:
            out = normalise(self.agent.act(state))
        except Exception:
            self.stats.note_error(traceback.format_exc(limit=6))
            out = None
        ms = (time.perf_counter() - t0) * 1000
        self.stats.total_ms += ms
        self.stats.max_ms = max(self.stats.max_ms, ms)
        return out

    def hand_end(self, summary):
        if hasattr(self.agent, "on_hand_end"):
            try:
                self.agent.on_hand_end(summary)
            except Exception:
                pass

    def close(self):
        pass
